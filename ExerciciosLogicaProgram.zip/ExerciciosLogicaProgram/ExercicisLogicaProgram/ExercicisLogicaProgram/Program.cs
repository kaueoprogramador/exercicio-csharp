﻿using System.Runtime.Intrinsics.X86;

//1 - (FGV / TCE - SE) Duas tartarugas estavam juntas e começaram a caminhar em linha reta em direção a um lago distante.
//A primeira tartaruga percorreu 30 metros por dia e demorou 16 dias para chegar ao lago.
//A segunda tartaruga só conseguiu percorrer 20 metros por dia e, portanto, chegou ao lago alguns dias depois da primeira.
//Quando a primeira tartaruga chegou ao lago, o número de dias que ela teve que esperar para a segunda tartaruga chegar foi:

//30m = 16d = 480m
//20m = X = 480m
//20m = 24 = 480m

//int distancia = 30 * 16;
//int diasSegunda = distancia / 20;
//int espera = diasSegunda - 16;
//Console.WriteLine("Exercicio 1: " + espera + " dias");



//******************************************************************************************************************************



//2 - (Enem)Jogar baralho é uma atividade que estimula o raciocínio. Um jogo tradicional é a Paciência, que utiliza 52 cartas.
//Inicialmente são formadas sete colunas com as cartas. A primeira coluna tem uma carta, a segunda tem duas cartas,
//a terceira tem três cartas, a quarta tem quatro cartas, e assim sucessivamente até a sétima coluna, a qual tem sete cartas,
//e o que sobra forma o monte, que são as cartas não utilizadas nas colunas.A quantidade de cartas que forma o monte é:

//int cartasNasColunas = 0;



//******************************************************************************************************************************



//3 - (CESGRANRIO)Uma pizzaria vende pizzas nos sabores calabresa, frango e quatro queijos.
//A borda pode ser tradicional ou recheada, e o tamanho pode ser médio ou grande.
//Quantas combinações diferentes de pizza o cliente pode pedir, considerando apenas um sabor por vez?

//int sabores = 3;
//int bordas = 2;
//int tamanhos = 2;

//int combinacoes = sabores * bordas * tamanhos;

//Console.WriteLine("Exercicio 3: " + combinacoes + " combinações");



//******************************************************************************************************************************



//4 - Descubra a lógica por trás de cada sequência e assinale a alternativa que apresenta corretamente
//o próximo elemento de cada uma delas:
//I) 1, 3, 5, 7, ?
//II) 2, 4, 8, 16, 32, 64, ?
//III) 0, 1, 4, 9, 16, 25, 36, ?
//IV) 4, 16, 36, 64, ?
//V) 1, 1, 2, 3, 5, 8, ?
//VI) 2, 10, 12, 16, 17, 18, 19, 

int celsius = 0;
if(celsius < 15)
{
    Console.WriteLine("agradavel");
}
else
{
    Console.WriteLine("quente"); 
}




int n = 3;
switch (n)
{
    case 1:
        Console.WriteLine("manha");

}




//------------------------------------------------------------------------------------------------------------------------------------


//1 - Dobro de um número
//Leia um número inteiro e mostre o dobro dele.

//Console.Write("Digite um número: ");
//double numero = double.Parse(Console.ReadLine());

//double dobro = numero * 2;

//Console.WriteLine($"O dobro é:{dobro}");




//2 - Soma simples
//Leia dois números e exiba a soma.



//3 - Par e ímpar
//Leia um número e informe se ele é par ou ímpar.



//4 - Maior número
//Leia dois números e informe qual é o maior.



//5 - Idade mínima
//Leia a idade de uma pessoa e informe se ela é maior de idade (18 anos ou mais).